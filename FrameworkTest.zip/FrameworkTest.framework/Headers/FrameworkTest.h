//
//  FrameworkTest.h
//  FrameworkTest
//
//  Created by Andy Stef on 21.09.2020.
//  Copyright © 2020 Andy Stef. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FrameworkTest.
FOUNDATION_EXPORT double FrameworkTestVersionNumber;

//! Project version string for FrameworkTest.
FOUNDATION_EXPORT const unsigned char FrameworkTestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameworkTest/PublicHeader.h>


